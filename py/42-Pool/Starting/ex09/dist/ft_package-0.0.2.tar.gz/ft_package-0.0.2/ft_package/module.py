def add_one(number):
    """add_one(number) method of builtins.list instance
    Return number+1."""

    return number + 1

def count_in_list(lst, word):
    """count(value, /) method of builtins.list instance
    Return number of occurrences of value."""
    
    return lst.count(word)

# print(help(count_in_list))